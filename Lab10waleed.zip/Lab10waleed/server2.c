#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 12345
#define MAX_BUFFER_SIZE 1024

char* reverse_modify(const char* data) 
{
    char* result = malloc(strlen(data) + 1);
    strcpy(result, data);

    for (size_t i = 0; i < strlen(result); ++i) 
    {
            result[i] -= 3;
     
            result[i] -= 2;
        
            result[i] -= 1;
        
    }

    return result;
}

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    listen(sockfd, 5);

    int new_sock = accept(sockfd, NULL, NULL);
    if (new_sock < 0) {
        perror("Accept failed");
        return 1;
    }

    char buffer[MAX_BUFFER_SIZE];
    recv(new_sock, buffer, sizeof(buffer), 0);
    char* reversed_data = reverse_modify(buffer);

    // Display the received and processed data on the screen
    printf("Received and Processed Data: %s\n", reversed_data);

    // Send the processed data back to the client
    send(new_sock, reversed_data, strlen(reversed_data), 0);

    close(new_sock);
    free(reversed_data);
    return 0;
}

