#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <arpa/inet.h> // Include this header file
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 

#define PORT 8080
#define MAXLINE 1024

int main() {
	int sockfd;
	struct sockaddr_in servaddr;
	char buffer[MAXLINE];
	char *message = "Hello from client";

	// Creating socket file descriptor
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror("socket creation failed");
		exit(EXIT_FAILURE);
	}

	memset(&servaddr, 0, sizeof(servaddr));

	// Filling server information
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(PORT);
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); // inet_addr is declared in <arpa/inet.h>

	// Connecting to the server
	if (connect(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
		perror("connection failed");
		exit(EXIT_FAILURE);
	}

	// Sending message to the server
	send(sockfd, message, strlen(message), 0);

	// Receiving message from the server
	memset(buffer, 0, MAXLINE);
	recv(sockfd, buffer, MAXLINE, 0);
	printf("Server message: %s\n", buffer);

	// Closing the socket
	close(sockfd);

	return 0;
}
