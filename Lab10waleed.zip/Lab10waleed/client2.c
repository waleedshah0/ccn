#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 12345
#define MAX_BUFFER_SIZE 1024

char* modify_data(const char* data) {
    char* result = malloc(strlen(data) + 1);
    strcpy(result, data);

    for (size_t i = 0; i < strlen(result); ++i) 
    {

            result[i] += 3;

            result[i] += 2;

            result[i] += 1;
        
    }

    return result;
}

int main() {
    char buffer[MAX_BUFFER_SIZE];
    FILE* file = fopen("fileData.txt", "r");
    if (!file) {
        perror("Failed to open file");
        return 1;
    }

    ssize_t bytes_read = fread(buffer, sizeof(char), MAX_BUFFER_SIZE, file);
    fclose(file);

    buffer[bytes_read] = '\0'; // Null-terminate the string

    char* modified_data = modify_data(buffer);

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        free(modified_data);
        return 1;
    }

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");
        free(modified_data);
        return 1;
    }

    send(sockfd, modified_data, strlen(modified_data), 0);
    close(sockfd);

    free(modified_data);
    return 0;
}

