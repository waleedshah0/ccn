#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 12345
#define MAX_BUFFER_SIZE 1024

void send_file_name(int sock, const char* file_name) {
    char buffer[MAX_BUFFER_SIZE];
    sprintf(buffer, "%s", file_name);
    send(sock, buffer, strlen(buffer), 0);
}

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

    // Display port number and process ID
    printf("Connected to server on port %d using process ID %d\n",
           ntohs(serv_addr.sin_port), getpid());

    // Send file name to server
    send_file_name(sockfd, "filedata.txt");

    // Receive file size
    long fsize;
    recv(sockfd, &fsize, sizeof(long), 0);
    printf("File size: %ld\n", fsize);

    // Receive file content
    FILE* fp = fopen("received_file.txt", "wb");
    if (!fp) {
        perror("Failed to open file");
        return 1;
    }
    recv(sockfd, fp, fsize, 0);
    fclose(fp);

    printf("File received successfully.\n");

    close(sockfd);
    return 0;
}

