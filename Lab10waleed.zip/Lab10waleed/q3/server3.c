#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 12345
#define MAX_BUFFER_SIZE 1024

void handle_client(int sock) {
    char buffer[MAX_BUFFER_SIZE];
    FILE* fp = NULL;

    // Receive file name from client
    recv(sock, buffer, sizeof(buffer), 0);
    printf("Client requested file: %s\n", buffer);

    // Open the requested file
    fp = fopen(buffer, "rb");
    if (!fp) {
        perror("Failed to open file");
        send(sock, "File not found", strlen("File not found"), 0);
        return;
    }

    // Send file content to client
    fseek(fp, 0, SEEK_END);
    long fsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    send(sock, &fsize, sizeof(long), 0); // Send file size

    // Allocate a buffer to hold the file content
    char* file_content = malloc(fsize);
    if (!file_content) {
        fclose(fp);
        send(sock, "Memory allocation failed", strlen("Memory allocation failed"), 0);
        return;
    }

    // Read the file content into the buffer
    fread(file_content, sizeof(char), fsize, fp);
    fclose(fp);

    // Send file content to client
    send(sock, file_content, fsize, 0); // Send file content

    // Cleanup
    free(file_content);
    send(sock, "File transferred successfully", strlen("File transferred successfully"), 0);
}

int main() {
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        return 1;
    }

    struct sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERVER_PORT);
    serv_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    bind(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    listen(sockfd, 5);
    
    while (1) {
        int new_sock = accept(sockfd, NULL, NULL);
        if (new_sock < 0) {
            perror("Accept failed");
            continue;
        }
	
        printf("New connection accepted. Socket: %d\n", new_sock);
        handle_client(new_sock);
        close(new_sock);
    }

    close(sockfd);
    return 0;
}

