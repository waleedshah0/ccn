// Server side implementation of TCP client-server model
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <string.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 

#define PORT	 8080 
#define MAXLINE 1024 

// Driver code 
int main() { 
	int sockfd, connfd; 
	char buffer[MAXLINE]; 
	char *hello = "Hello from server"; 
	struct sockaddr_in servaddr, cliaddr; 
	socklen_t len; // Declare len here

	// Creating socket file descriptor 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) {
		perror("socket creation failed");
		exit(EXIT_FAILURE);
	}

	memset(&servaddr, 0, sizeof(servaddr)); 

	// Filling server information 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = INADDR_ANY; 
	servaddr.sin_port = htons(PORT); 

	// Bind the socket with the server address 
	if (bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	// Listen for incoming connections
	listen(sockfd, 5);

	printf("Waiting for client connection...\n");

	// Accept incoming connection
	connfd = accept(sockfd, (struct sockaddr *) &cliaddr, &len);

	// Check if connection was accepted
	if (connfd < 0) {
		perror("accept failed");
		exit(EXIT_FAILURE);
	}

	printf("Connected to client...\n");

	// Receive message from client
	recv(connfd, buffer, MAXLINE, 0);
	printf("Client message: %s\n", buffer);

	// Send message to client
	send(connfd, hello, strlen(hello), 0);
	printf("Hello message sent to client.\n");

	// Close the socket
	close(connfd);
	close(sockfd);

	return 0;
}
